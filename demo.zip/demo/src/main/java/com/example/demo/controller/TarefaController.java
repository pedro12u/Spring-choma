package com.example.demo.controller;

import com.example.demo.service.TarefaService;
import com.example.demo.model.Tarefa;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/tarefa")
public class TarefaController {

    @Autowired
    private TarefaService tarefaService;

    @GetMapping
    public ResponseEntity<List<Tarefa>> listarTodas() {
        return ResponseEntity.ok(tarefaService.buscarTodas());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Tarefa> buscarPorId(@PathVariable int id) {
        return ResponseEntity.ok(tarefaService.buscarPorId(id));
    }

    @GetMapping("/status/{stat}")
    public ResponseEntity<List<Tarefa>> buscarPorStatus(@PathVariable int stat) {
        return ResponseEntity.ok(tarefaService.buscarPorStatus(stat));
    }

    @PostMapping
    public ResponseEntity<Tarefa> criar(@RequestBody Tarefa tarefa) {
        return ResponseEntity.ok(tarefaService.salvar(tarefa));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Tarefa> editar(@PathVariable int id, @RequestBody Tarefa tarefa) {
        return ResponseEntity.ok(tarefaService.editarTarefa(id, tarefa));
    }

    @PutMapping("/{id}/mover")
    public ResponseEntity<Tarefa> mover(@PathVariable int id) {
        return ResponseEntity.ok(tarefaService.mover(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> excluir(@PathVariable int id) {
        tarefaService.excluir(id);
        return ResponseEntity.ok("Tarefa com ID " + id + " excluída com sucesso.");
    }
}
