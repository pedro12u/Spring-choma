package com.example.demo.security;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
public class ProvedorChaveSecreta {

    private static final Logger logger = LoggerFactory.getLogger(ProvedorChaveSecreta.class);

    @Value("${JWT_SECRET}")
    private String chaveSecretaBase64;

    private SecretKey chaveSecreta;

    @PostConstruct
    public void inicializar() {
        logger.info("Iniciando ProvedorChaveSecreta com JWT_SECRET: {}", chaveSecretaBase64);
        try {
            byte[] chaveDecodificada = Base64.getDecoder().decode(chaveSecretaBase64);
            chaveSecreta = new SecretKeySpec(chaveDecodificada, 0, chaveDecodificada.length, "HmacSHA256");
            logger.info("Chave secreta inicializada com sucesso.");
        } catch (IllegalArgumentException e) {
            logger.error("Erro ao inicializar a chave secreta. Certifique-se de que JWT_SECRET é válido.", e);
            throw new RuntimeException("JWT_SECRET inválido nas configurações.", e);
        }
    }

    public SecretKey obterChaveSecreta() {
        return chaveSecreta;
    }

    public String obterChaveSecretaBase64() {
        return chaveSecretaBase64;
    }
}
