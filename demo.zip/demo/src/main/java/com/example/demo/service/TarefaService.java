package com.example.demo.service;

import com.example.demo.model.Tarefa;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.repository.TarefaRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class TarefaService {

    @Autowired
    private TarefaRepository tarefaRepository;

    public Tarefa buscarPorId(int id) {
        return tarefaRepository.findById(id).orElseThrow(() -> 
            new RuntimeException("Tarefa com ID " + id + " não encontrada."));
    }

    public List<Tarefa> buscarTodas() {
        return tarefaRepository.findAll();
    }

    public List<Tarefa> buscarPorStatus(int nStat) {
        String status = switch (nStat) {
            case 1 -> "Pendente";
            case 2 -> "Em andamento";
            case 3 -> "Concluída";
            default -> null;
        };

        if (status == null) {
            throw new IllegalArgumentException("Status inválido. Use 1 (Pendente), 2 (Em andamento) ou 3 (Concluída).");
        }

        List<Tarefa> tarefas = tarefaRepository.findAll();
        List<Tarefa> filtradas = new ArrayList<>();

        String[] prioridades = {"Baixa", "Média", "Alta"};
        for (String prioridade : prioridades) {
            tarefas.stream()
                    .filter(t -> t.getStatus().equals(status) && t.getPrioridade().equals(prioridade))
                    .forEach(filtradas::add);
        }

        return filtradas;
    }

    public Tarefa salvar(Tarefa tarefa) {
        return tarefaRepository.save(tarefa);
    }

    public void excluir(int id) {
        Tarefa tarefa = buscarPorId(id);
        tarefaRepository.deleteById(id);
        System.out.println("Tarefa " + id + " excluída.");
    }

    public Tarefa mover(int id) {
        Tarefa tarefa = buscarPorId(id);
        switch (tarefa.getStatus()) {
            case "Pendente" -> tarefa.setStatus("Em andamento");
            case "Em andamento" -> tarefa.setStatus("Concluída");
            default -> throw new RuntimeException("Tarefa já está concluída.");
        }
        return tarefaRepository.save(tarefa);
    }

    public Tarefa editarTarefa(int id, Tarefa novaTarefa) {
        Tarefa tarefaExistente = buscarPorId(id);

        if (novaTarefa.getDescricao() != null) {
            tarefaExistente.setDescricao(novaTarefa.getDescricao());
        }
        if (novaTarefa.getPrioridade() != null) {
            tarefaExistente.setPrioridade(novaTarefa.getPrioridade());
        }
        if (novaTarefa.getTitulo() != null) {
            tarefaExistente.setTitulo(novaTarefa.getTitulo());
        }

        return tarefaRepository.save(tarefaExistente);
    }
}
